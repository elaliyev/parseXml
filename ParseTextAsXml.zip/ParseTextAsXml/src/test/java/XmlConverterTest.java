import model.Sentence;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import service.SentenceConverter;
import service.TextConverter;
import service.XmlConverter;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class XmlConverterTest {

    private static SentenceConverter xmlConverter;
    private static File outputFile = new File("/Users/elvinaliyev/Documents/sample-files/output.xml");

    @BeforeAll
    static void initAll() {
        xmlConverter = new XmlConverter(outputFile, null);
    }

    @Test
    public void testWhenContentOfOutputFileIsCorrect() throws IOException {
        Path path2 = Files.createTempFile("actual", ".xml");
        Files.writeString(path2, TestUtil.getTestData());

        xmlConverter.saveAsFile(getContentFromFile());

        Reader reader1 = new BufferedReader(new FileReader(outputFile));
        Reader reader2 = new BufferedReader(new FileReader(path2.toFile()));

        assertTrue(IOUtils.contentEqualsIgnoreEOL(reader1, reader2));
    }

    private String getContentFromFile() throws FileNotFoundException {
        String inputFile = "/Users/elvinaliyev/Documents/sample-files/small.in";
        BufferedReader reader = new BufferedReader
                (new InputStreamReader(new FileInputStream(inputFile), StandardCharsets.UTF_8));
        String text = reader.lines().collect(Collectors.joining());
        TextConverter converter = new TextConverter();
        Map<Sentence, List<String>> sentenceToWordsMap = converter.parseText(text);

        String content = xmlConverter.convert(sentenceToWordsMap);
        return content;
    }

}
