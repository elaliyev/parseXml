import model.Sentence;

import service.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class ParseTextAsXml {

    public static void main(String[] args) throws IOException {
        String xmlOutputFile = "/Users/elvinaliyev/Documents/sample-files/output.xml";

        String text = getText();
        TextConverter converter = new TextConverter();

        Map<Sentence, List<String>> sentenceToWordsMap = converter.parseText(text);
        SentenceConverter xmlConverter = new XmlConverter(new File(xmlOutputFile), null);
        String xmlContent = xmlConverter.convert(sentenceToWordsMap);
//        System.out.println("XML Output:\n" + xmlContent);
        xmlConverter.saveAsFile(xmlContent);
    }

    private static String getText() throws FileNotFoundException {
        String inputFile = "/Users/elvinaliyev/Documents/sample-files/small.in";
        BufferedReader reader = new BufferedReader
                (new InputStreamReader(new FileInputStream(inputFile), StandardCharsets.UTF_8));
        return reader.lines().collect(Collectors.joining());
    }

}
