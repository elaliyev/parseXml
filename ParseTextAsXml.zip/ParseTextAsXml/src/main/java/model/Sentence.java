package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sentence {

    private static final Pattern PATTERN_SPLIT_WORDS = Pattern.compile("\\p{L}+('\\p{L}+)?");

    private final String text;
    private final List<String> words;

    public Sentence(String text) {
        this.text = text;
        this.words = new ArrayList<>();
        parseWords();
    }

    private void parseWords() {
        Matcher matcher = PATTERN_SPLIT_WORDS.matcher(this.text);
        while (matcher.find()) {
            String word = matcher.group().trim();
            words.add(word);
        }
       Collections.sort(words, String.CASE_INSENSITIVE_ORDER);
    }
    public String getText() {
        return text;
    }

    public List<String> getWords() {
        return words;
    }

}
