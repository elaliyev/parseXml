package service;

import model.Sentence;

import java.util.List;
import java.util.Map;

public interface SentenceConverter {
    String convert(Map<Sentence, List<String>> sentenceToWordsMap);

    void saveAsFile(String content);
}
