package service;

import model.Sentence;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextConverter {

    private static final Pattern PATTERN_FOR_FIND_ABBREVIATION_WHEN_CAPITAL_LETTERS_FOLLOWED = Pattern.compile("([A-Z][a-z]+\\.)(\\s+)(?=[A-Z])");
    private static final Pattern PATTERN_SPLIT_TEXT_BY_SENTENCES = Pattern.compile("(?<!\\w\\.\\w.)(?<![A-Z][a-z]\\.)(?<=\\.|\\?|!)\\s");

    public Map<Sentence, List<String>> parseText(String text) {
        Map<Sentence, List<String>> sentenceToWords = new LinkedHashMap<>();
        List<String> sentences = getSentences(text);
        for (String sentence : sentences) {
            Sentence s = new Sentence(sentence);
            sentenceToWords.put(s, s.getWords());
        }
        return sentenceToWords;
    }

    private List<String> getSentences(String text) {
        text = cleanUpText(text);
        return splitTextBySentences(text);
    }

    private String cleanUpText(String text) {
        text = addWhiteSpacesToBeginningSentence(text);
        Matcher matcher = PATTERN_FOR_FIND_ABBREVIATION_WHEN_CAPITAL_LETTERS_FOLLOWED.matcher(text);
        while (matcher.find()) {
            text = text.replaceAll(matcher.group(),
                    matcher.group().substring(0, matcher.group().length() - 1));
        }
        return text;
    }


    private String addWhiteSpacesToBeginningSentence(String text) {
        return text.replaceAll("\\.(?!\\s)", ". ");
    }

    private List<String> splitTextBySentences(String text) {
        List<String> sentences = new ArrayList<>();
        Matcher matcher = PATTERN_SPLIT_TEXT_BY_SENTENCES.matcher(text);
        int start = 0;
        while (matcher.find()) {
            sentences.add(text.substring(start, matcher.start() + 1).trim());
            start = matcher.end();
        }
        if (start < text.length()) {
            sentences.add(text.substring(start).trim());
        }
        return sentences;
    }
}