package service;

import model.Sentence;

import java.io.*;
import java.util.List;
import java.util.Map;

public class CsvConverter implements SentenceConverter {

    private final File outputFile;

    public CsvConverter(File outputFile) {
        this.outputFile = outputFile;
    }

    @Override
    public String convert(Map<Sentence, List<String>> sentenceToWordsMap) {
        StringBuilder csv = new StringBuilder();
        String header = createCSVHeaders(sentenceToWordsMap);
        csv.append(header);
        int i=1;
        for (Sentence sentence : sentenceToWordsMap.keySet()) {
            csv.append("Sentence " + i).append(" ");
            for (String word : sentence.getWords()) {
                csv.append(word).append(",");
            }
            csv.deleteCharAt(csv.length() - 1); // Remove extra comma
            csv.append("\"\n");
            i++;
        }
        return csv.toString();
    }

    public static String createCSVHeaders(Map<Sentence, List<String>> sentenceToWordsMap) {
        int maxWords = 0;
        for (List<String> words : sentenceToWordsMap.values()) {
            maxWords = Math.max(maxWords, words.size());
        }

        StringBuilder headers = new StringBuilder();
        headers.append("\t \t \t");//it is for sentences header
        for (int i = 1; i < maxWords; i++) {
            headers.append("word").append(i);
            if (i < maxWords-1) {
                headers.append(",");
            }
        }

        return headers.append("\n").toString();
    }

    @Override
    public void saveAsFile(String content) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
            writer.print(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
