package service;

import model.Sentence;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.List;
import java.util.Map;

public class XmlConverter implements SentenceConverter {

    protected final File xmlFile;
    protected final File outputTxtFile;

    public XmlConverter(File xmlFile, File outputTxtFile) {
        this.xmlFile = xmlFile;
        this.outputTxtFile = outputTxtFile;

        if (xmlFile != null && xmlFile.exists())
            xmlFile.delete();

        if (outputTxtFile != null && outputTxtFile.exists())
            outputTxtFile.delete();
    }

    @Override
    public String convert(Map<Sentence, List<String>> sentenceToWordsMap) {
        StringBuilder xml = new StringBuilder();
        for (Sentence sentence : sentenceToWordsMap.keySet()) {
            xml.append("<sentence>");
            for (String word : sentence.getWords()) {
                xml.append("<word>").append(word).append("</word>");
            }
            xml.append("</sentence>");
        }
        return xml.toString();
    }

    @Override
    public void saveAsFile(String content) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            content = wrapWithRootElement(content);
            Document document = builder.parse(new InputSource(
                    new StringReader(content)));

            TransformerFactory tranFactory = TransformerFactory.newInstance();
            Transformer transformer = tranFactory.newTransformer();

            transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.setOutputProperty("{http://xml.apache.org/xalan}indent-amount", "2");
            Source src = new DOMSource(document);
            Result dest = new StreamResult(xmlFile);
            transformer.transform(src, dest);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String wrapWithRootElement(String content) {
        return "<text>" + content + "</text>";
    }

}
