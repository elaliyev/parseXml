package service;

import java.io.*;

public class HugeXmlFileConverter extends XmlConverter{

    public HugeXmlFileConverter(File xmlFile, File outputTxtFile) {
        super(xmlFile, outputTxtFile);
        createTextFileWithHeader(outputTxtFile);
    }

    private  void createTextFileWithHeader(File file) {
        try {
            FileWriter writer = new FileWriter(file);
            StringBuilder builder = new StringBuilder();
            builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            builder.append("<text>\n");
            writer.write(builder.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addLinesToFile(String lines) {
        try (PrintWriter writer = new PrintWriter(new FileOutputStream(outputTxtFile, true))) {
            writer.println(lines +"\n");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void closeTextFile(File file) {
        try (PrintWriter writer = new PrintWriter(new FileOutputStream(file, true))) {
            writer.println("</text>");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
