import model.Sentence;
import service.CsvConverter;
import service.SentenceConverter;
import service.TextConverter;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class ParseCsvFile {

    public static void main(String[] args) throws IOException {
        String csvOutputFile = "/Users/elvinaliyev/Documents/sample-files/output.csv";

        String text = getText();
        TextConverter converter = new TextConverter();

        Map<Sentence, List<String>> sentenceToWordsMap = converter.parseText(text);
        SentenceConverter csvConverter = new CsvConverter(new File(csvOutputFile));
        String csvContent = csvConverter.convert(sentenceToWordsMap);
        System.out.println(csvContent);
    }

    private static String getText() throws FileNotFoundException {
        String inputFile = "/Users/elvinaliyev/Documents/sample-files/small.in";
        BufferedReader reader = new BufferedReader
                (new InputStreamReader(new FileInputStream(inputFile), StandardCharsets.UTF_8));
        String text = reader.lines().collect(Collectors.joining());
        return text;
    }
}
