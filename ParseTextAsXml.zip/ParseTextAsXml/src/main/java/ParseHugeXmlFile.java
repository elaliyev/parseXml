import model.Sentence;
import service.HugeXmlFileConverter;
import service.TextConverter;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * @author Elvin Aliyev
 * @date 2024.02.25
 */
public class ParseHugeXmlFile {

    public static void main(String[] args) throws IOException {
        String inputFileName = "/Users/elvinaliyev/Documents/sample-files/large.in";
        String outputTextFile = "/Users/elvinaliyev/Documents/sample-files/output.txt";
        TextConverter converter = new TextConverter();
        HugeXmlFileConverter xmlConverter = new HugeXmlFileConverter(null, new File(outputTextFile));
        try (Stream<String> lines = java.nio.file.Files.lines(Paths.get(inputFileName))) {
            lines.forEach(line -> {
                Map<Sentence, List<String>> sentenceToWordsMap = converter.parseText(line);
                String xmlContent = xmlConverter.convert(sentenceToWordsMap);
//                System.out.println("XML Output:\n" + xmlContent);
                xmlConverter.addLinesToFile(xmlContent);
            });
        }
        xmlConverter.closeTextFile(new File(outputTextFile));
    }
}
